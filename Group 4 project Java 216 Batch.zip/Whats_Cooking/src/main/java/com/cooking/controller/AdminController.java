package com.cooking.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cooking.model.RecipeModel;
import com.cooking.repository.AdminRepository;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/cooking/api/")
public class AdminController {

	@Autowired
	AdminRepository adminRepository;
	
	@PostMapping("/saverecipe")
	public RecipeModel saveUsers(@Validated @RequestBody RecipeModel recipeModel) {
		
		RecipeModel rm=new RecipeModel();
		rm.setItemname(recipeModel.getItemname());
		rm.setIngredients(recipeModel.getIngredients());
		rm.setCookingsteps(recipeModel.getCookingsteps());
		rm.getStatus();
		rm.setStatus("waiting");
		return adminRepository.save(rm);
	}
	@GetMapping("/viewrecipe")
	public List<RecipeModel> viewAllRecipe() {
	return adminRepository.findAll();
	}
	
	@GetMapping("/removerecipe")
	public void removeRecipe(@RequestParam int id) {
	adminRepository.deleteById(id);
	}
	
	@GetMapping("/enable")
	public void enableModel(@RequestParam int id) {
		RecipeModel rm=adminRepository.findById(id);	
		rm.getStatus();
		rm.setStatus("Enable");
		adminRepository.save(rm);
	}
	
	@GetMapping("/disable")
	public void disableModel(@RequestParam int id) {
		RecipeModel rm=adminRepository.findById(id);	
		rm.getStatus();
		rm.setStatus("Disable");
		adminRepository.save(rm);
	}
}
