package com.cooking.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cooking.model.RecipeModel;
import com.cooking.model.UserModel;
import com.cooking.repository.AdminRepository;
import com.cooking.repository.UserRepository;
import java.util.List;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/cooking/api/")
public class UserController {

	@Autowired
	UserRepository userRepository;
	
	@PostMapping("/saveuser")
	public UserModel saveUsers(@Validated @RequestBody UserModel userModel) {
		return userRepository.save(userModel);
	}
	
	@GetMapping("/loginuser")
	public UserModel loginUser(@RequestParam String username,@RequestParam String password) {
		return userRepository.findByUsernameAndPassword(username, password);
	}
	@Autowired
	AdminRepository adminRepository;
	
	@GetMapping("/searchrecipe")
	public List<RecipeModel> serachRecipe(@RequestParam String itemname) {
		return adminRepository.findByItemname(itemname);
	}
	
	@GetMapping("/getrecipedetails")
	public RecipeModel getRecipeById(@RequestParam int id){
	return adminRepository.findById(id);
}
}
