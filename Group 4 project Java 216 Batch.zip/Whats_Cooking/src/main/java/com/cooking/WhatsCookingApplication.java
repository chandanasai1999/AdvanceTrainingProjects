package com.cooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhatsCookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(WhatsCookingApplication.class, args);
	}

}
