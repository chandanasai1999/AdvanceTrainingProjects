package com.cooking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cooking.model.RecipeModel;
import java.util.List;

public interface AdminRepository extends JpaRepository<RecipeModel,Integer>{
	public RecipeModel findById(int id);
public List<RecipeModel> findByItemname(String name);

}
