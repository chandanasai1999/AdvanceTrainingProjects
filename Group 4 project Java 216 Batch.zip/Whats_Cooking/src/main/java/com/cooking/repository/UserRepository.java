package com.cooking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cooking.model.UserModel;


public interface UserRepository extends JpaRepository<UserModel,Integer>{
 public UserModel findByUsernameAndPassword(String username,String password);
}
