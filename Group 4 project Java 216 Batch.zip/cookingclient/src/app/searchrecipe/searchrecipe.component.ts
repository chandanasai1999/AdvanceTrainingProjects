import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Recipes } from '../recipemodel';
import { UserService } from '../user.service';

@Component({
  selector: 'app-searchrecipe',
  templateUrl: './searchrecipe.component.html',
  styleUrls: ['./searchrecipe.component.css']
})
export class SearchrecipeComponent implements OnInit {
itemname='';
recipe?:Recipes[];
  constructor(private router:Router,private userService:UserService) { }

  ngOnInit(): void {
    this.recipeSearch();
  }
  recipeSearch(){
    this.userService.searchRecipe(this.itemname).subscribe(
      data=>{
        this.recipe=data;
      }
    );
    }
    
onRecipeSearch(){
this.recipeSearch();
this.gotoSearchRecipe();
  }
  gotoSearchRecipe(){
    this.router.navigate(['searchrecipe']);
  }
}
