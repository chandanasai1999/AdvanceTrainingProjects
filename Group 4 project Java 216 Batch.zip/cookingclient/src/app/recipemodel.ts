export class Recipes{
    id:number=0;
    itemname:string='';
    ingredients:string='';
    cookingsteps:string='';
    status:string='';
}