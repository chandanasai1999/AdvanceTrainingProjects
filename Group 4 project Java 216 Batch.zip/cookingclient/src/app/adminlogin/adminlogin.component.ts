import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {
username='';
password='';
invalidLogin=false;
  constructor(private router:Router,private adminService:AdminService) { }

  ngOnInit(): void {
  }
  checkLogin(){
    if(this.adminService.authenticate(this.username,this.password)){
this.router.navigate([''])
this.invalidLogin=false;
    }else{
      this.invalidLogin=true;
    }
  }
  logOut(){
    sessionStorage.removeItem('username');
  }
}
