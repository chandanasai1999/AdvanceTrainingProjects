import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Users } from './usermodel';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  users?:Users;
  constructor(private httpclient:HttpClient) { }
  userLogin(username:string,password:string):Observable<any>{
    return this.httpclient.get("http://localhost:1029/whats_cooking/cooking/api/loginuser?username="+username+"&password="+password);
  }
  userRegister(user:Object): Observable<Object>{
    return this.httpclient.post('http://localhost:1029/whats_cooking/cooking/api/saveuser',user);
    }
    searchRecipe(itemname:string):Observable<any>{
      return this.httpclient.get("http://localhost:1029/whats_cooking/cooking/api/searchrecipe?itemname="+itemname);
    }
    getRecipeDetails(id:number):Observable<any>{
      return this.httpclient.get("http://localhost:1029/whats_cooking/cooking/api/getrecipedetails?id="+id);
    }
  
  authenticate(username:string, password:string) {
    
    this.userLogin(username,password).subscribe(
      data=>{
        this.users=data;
      }
    );
    if (this.users) {
      console.log(this.users?.username)
      sessionStorage.setItem('name', username)
      console.log("username:"+username);
      return true;
    } else {
      return false;
    }
  }
  isUserLoggedIn() {
    let name = sessionStorage.getItem('name')
    console.log(!(name === null))
    return !(name === null)
  }
  
  logOut() {
    sessionStorage.removeItem('name')
  }
}
