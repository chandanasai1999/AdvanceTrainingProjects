export class Users{
    id:number=0;
    name:string='';
    email:string='';
    mobile:string='';
    username:string='';
    password:string='';
    active:boolean=false;
}