import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { Recipes } from '../recipemodel';

@Component({
  selector: 'app-viewrecipe',
  templateUrl: './viewrecipe.component.html',
  styleUrls: ['./viewrecipe.component.css']
})
export class ViewrecipeComponent implements OnInit {
recipe?:Recipes[];
  constructor(private router:Router,private adminService:AdminService) { }

  ngOnInit(): void {
  this.getRecipes();
  this.gotoViewrecipe();
    
  }

getRecipes(){
  this.adminService.getAllRecipes().subscribe(
    data=>{
      this.recipe=data;
    }
  );
}

  removingItem(id:number){
    this.adminService.removeRecipeById(id).subscribe();
     
}
  removeItem(id:number){
    this.removingItem(id)
    this.ngOnInit(); 
    this.gotoViewrecipe();
  }
    setEnableItem(id: number){
    this.adminService.setEnableRecipe(id).subscribe();
    }
    
    enableItem(id:number){
    this.setEnableItem(id);
    this.gotoViewrecipe();
      }
    
      disableItem(id:number){
        this.adminService.setDisableRecipe(id).subscribe();
        this.gotoViewrecipe();
      }
    
  gotoViewrecipe(){
    this.router.navigate(['viewrecipes']);
  }
}
