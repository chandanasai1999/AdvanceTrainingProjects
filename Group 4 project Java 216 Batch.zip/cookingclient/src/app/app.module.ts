import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminlogoutComponent } from './adminlogout/adminlogout.component';
import { AddrecipeComponent } from './addrecipe/addrecipe.component';
import { ViewrecipeComponent } from './viewrecipe/viewrecipe.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UserregisterComponent } from './userregister/userregister.component';
import { SearchrecipeComponent } from './searchrecipe/searchrecipe.component';
import { UserlogoutComponent } from './userlogout/userlogout.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    AdminloginComponent,
    AdminlogoutComponent,
    AddrecipeComponent,
    ViewrecipeComponent,
    UserloginComponent,
    UserregisterComponent,
    SearchrecipeComponent,
    UserlogoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
