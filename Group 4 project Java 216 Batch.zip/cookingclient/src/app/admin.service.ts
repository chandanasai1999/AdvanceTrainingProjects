import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
invalidLogin=false;
  constructor(private httpClient:HttpClient) { }
  
  addRecipe(recipe:Object): Observable<Object>{
    return this.httpClient.post('http://localhost:1018/whats_cooking/cooking/api/saverecipe',recipe);
  }
    getAllRecipes(): Observable<any>{
      return this.httpClient.get('http://localhost:1018/whats_cooking/cooking/api/viewrecipe');
    }
    removeRecipeById(id: number): Observable<any>{
      return this.httpClient.get('http://localhost:1018/whats_cooking/cooking/api/removerecipe?id='+id);
    }
    setEnableRecipe(id: number):Observable<any>{
      return this.httpClient.get('http://localhost:1018/whats_cooking/cooking/api/enable?id='+id);
    }
    
    setDisableRecipe(id: number):Observable<any>{
      return this.httpClient.get('http://localhost:1018/whats_cooking/cooking/api/disable?id='+id);
    }
  authenticate(username:string,password:string){
    if(username ==="Admin" && password ==="Admin"){
      sessionStorage.setItem('username',username);
    return true;
    }else{
      return false;
    }
      }
      isAdminLoggedIn() {
        let user = sessionStorage.getItem('username')
        console.log(!(user === null))
        return !(user === null)
      }
      logOut(){
        sessionStorage.removeItem('username');
      }
}
