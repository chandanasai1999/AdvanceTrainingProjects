import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { Recipes } from '../recipemodel';

@Component({
  selector: 'app-addrecipe',
  templateUrl: './addrecipe.component.html',
  styleUrls: ['./addrecipe.component.css']
})
export class AddrecipeComponent implements OnInit {
recipe:Recipes=new Recipes();
submitted=false;
  constructor(private router:Router,private adminService:AdminService) { }

  ngOnInit(): void {
    this.gotoAddRecipe();
  }
addRecipe(){
  this.adminService.addRecipe(this.recipe).subscribe(
    data=>{
      this.recipe=new Recipes;
    }
  );
}
onSubmit(){
this.submitted=true;
this.addRecipe();
this.gotoAddRecipe();
  }
  gotoAddRecipe(){
    this.router.navigate(['/addrecipe']);
    }
}
