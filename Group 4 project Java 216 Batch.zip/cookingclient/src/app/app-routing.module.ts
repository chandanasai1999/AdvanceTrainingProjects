import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddrecipeComponent } from './addrecipe/addrecipe.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminlogoutComponent } from './adminlogout/adminlogout.component';
import { SearchrecipeComponent } from './searchrecipe/searchrecipe.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UserlogoutComponent } from './userlogout/userlogout.component';
import { UserregisterComponent } from './userregister/userregister.component';
import { ViewrecipeComponent } from './viewrecipe/viewrecipe.component';

const routes: Routes = [
  {path:'',redirectTo:'',pathMatch:'full'},
  {path:'adminlogin',component:AdminloginComponent},
  {path:'addrecipe',component:AddrecipeComponent},
  {path:'viewrecipes',component:ViewrecipeComponent},
  {path:'adminlogout',component:AdminlogoutComponent},
  {path:'userregister',component:UserregisterComponent},
  {path:'userlogin',component:UserloginComponent},
  {path:'searchrecipe',component:SearchrecipeComponent},
  {path:'userlogout',component:UserlogoutComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
